# curl_lib

`curl_lib` is a Python library that mimics the functionality of the `curl` command. It supports sending HTTP requests (GET, POST, PUT), handling cookies, and HTTPS support.

## Installation

To install the library, run:
pip install .

